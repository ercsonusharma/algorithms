#include<stdio.h>

int main()
{
    printf("ACM-CIC"+4);// CIC
	printf(4+"\nACM-CIC\n");// -CIC
	return 0;
}
